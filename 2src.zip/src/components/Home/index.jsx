import React from "react";
import "./style.css";
import AllPosts from "../AllPosts";

export default () => {
  return (
    <div>

      <h1>Welcome to the world</h1>
      <AllPosts/>
    </div>
  );
};
