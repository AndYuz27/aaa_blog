import React, {useContext, useState, useEffect} from "react";
import "./style.css";
import { Link } from 'react-router-dom';
export default ({ post }) => {
  const [modalView, setModal] = useState(false);
  const [modalAuth, setModalAuth] = useState(true);

  // console.log({data})


  return (
    <div className="pcard">
        <div className="img_blank" style={{backgroundImage: `url(${post.image !== undefined ? post.image : "https://velaxom.ru/assets/images/rasprodazha/kessler-parts/no-image.png"})`}}></div>
        <div className="post__wrapper">
            <h3 className="post__title">
            <Link to={`/blog-react/post/${post._id}`}>{post.title}</Link>
            </h3>
            {/* <LikeBtn post={post}/> */}

        </div>
    </div>
);
};
//        {posts.map((post) => {
//          return ( <div className="pcard">
//            <div className="img_blank" style={{backgroundImage: `url(${post.image !== undefined ? post.image : "https://velaxom.ru/assets/images/rasprodazha/kessler-parts/no-image.png"})`}}></div>
//          <div className="jj">
//          <p className="ptitle">{/*{data.title}*/}
//          <Link to={`/blog-react/post/${post._id}`}>{post.title}</Link>
//          </p>
//          </div>
//          {/* <p className="ptitle">{data.text}</p> */}
//          {/* <img src={data.image} alt="pic" width="256px"/> */}
//          </div>
//          )
//        })}