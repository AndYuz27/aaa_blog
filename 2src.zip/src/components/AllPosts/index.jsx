import React, {useContext, useState, useEffect} from "react";
import "./style.css";
// import posts from "../../data/posts.json";
import Api from "../../api";
import { Link } from 'react-router-dom';
import { Ctx } from "../../App";
import {remove} from "../../uu.js"
import axios from "axios";
import Post from "../Post"

export default () => {
      const {api} = useContext(Ctx);


      const [posts, setPosts] = useState([]);
const [isLoad, setIsLoad] = useState(false);
const [postTags, setPostTags] = useState([]);

const [querySearch, setQuerySearch] = useState("");
const [selectedTags, setSelectedTags] = useState([]);



 useEffect(() => {
  axios.get(`https://ithub-blog.herokuapp.com/api/posts`)
  .then((GetData) => {
    setPosts(GetData.data.data)
    setIsLoad(true);
    console.log("Data Posts",GetData.data.data)
  })
 })



  return (
    <div>
      <h1>All Posts</h1>
      
      <div className="posts__filter">
                    <input className="posts__filter-input" onChange={(evt) => setQuerySearch(evt.target.value)} type="text" placeholder="Search..." />
                    <div className="posts__filter-tags">
                        <h3 className="posts__filter-tags-title">Tags:</h3>
                        {isLoad ? posts.forEach((post) => {
                            if (post.tags.length > 0) {
                                for (let i = 0; i < post.tags.length; i++) {
                                    if (!postTags.includes(post.tags[i])) {
                                        setPostTags([...postTags, post.tags[i]]);
                                    }
                                }
                            }
                        }) : ''}

                        {isLoad ? postTags.map((tag, index) => {
                            return (
                                <button key={index} onClick={() => {
                                    if (!selectedTags.includes(tag)) {
                                        setSelectedTags([...selectedTags, tag]);
                                    } else {
                                        setSelectedTags(remove(selectedTags, tag));
                                    }
                                }} className={selectedTags.includes(tag) ? "posts__tag-btn posts__tag-btn--active" : "posts__tag-btn"}>{tag}</button>
                            );
                        }) : ''}
                    </div>
                </div>
      
      <div className="mmain">
      {isLoad ? posts.filter(post => {
                        if (querySearch === "") {
                            return post;
                        } else if (post.title && post.title.toLowerCase().includes(querySearch.toLowerCase())) {
                            return post;
                        }
                        return false;
                    }).filter((post) => {
                        if (selectedTags.length === 0) {
                            return post;
                        } else if (post.tags) {
                            for (let i = 0; i < selectedTags.length; i++) {
                                if (post.tags.includes(selectedTags[i])) {
                                    return post;
                                }
                            }
                        }
                        return false;
                    }).map((post) => {
                        return <Post key={post._id} post={post}></Post>
                    }) : <p>Загрузка...</p>}

    </div>
    </div>
  );
};
 